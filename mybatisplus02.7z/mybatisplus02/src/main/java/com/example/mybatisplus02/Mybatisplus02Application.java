package com.example.mybatisplus02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mybatisplus02Application {

    public static void main(String[] args) {
        SpringApplication.run(Mybatisplus02Application.class, args);
    }

}
